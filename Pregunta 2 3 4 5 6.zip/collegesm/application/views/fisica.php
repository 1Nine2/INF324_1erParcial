<?php include("inc/header.php"); ?>
	<div class="container">
			<h3 class="display-3" style="text-align:center;">Bienvienido a la Carrera de Fisica</h3>
			<hr>
			<button type="button" class="btn btn-primary">Primary</button>
			<button type="button" class="btn btn-secondary">Secondary</button>
			<button type="button" class="btn btn-success">Success</button>
			<button type="button" class="btn btn-info">Info</button>
			<button type="button" class="btn btn-warning">Warning</button>
			<button type="button" class="btn btn-danger">Danger</button>
			<button type="button" class="btn btn-light">Light</button>
			<button type="button" class="btn btn-dark">Dark</button>
			<button type="button" class="btn btn-link">Link</button>

	</div>


<?php include("inc/footer.php"); ?>