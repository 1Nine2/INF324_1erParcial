<?php include("inc/header.php"); ?>
	<div class="container">
			<h3 class="display-3" style="text-align:center;">Bienvienido a la Carrera de Informatica</h3>
			<hr>
			<button type="button" class="btn btn-primary disabled">Primary</button>
<button type="button" class="btn btn-secondary disabled">Secondary</button>
<button type="button" class="btn btn-success disabled">Success</button>
<button type="button" class="btn btn-info disabled">Info</button>
<button type="button" class="btn btn-warning disabled">Warning</button>
<button type="button" class="btn btn-danger disabled">Danger</button>
<button type="button" class="btn btn-light disabled">Light</button>
<button type="button" class="btn btn-dark disabled">Dark</button>
<button type="button" class="btn btn-link disabled">Link</button>

	</div>


<?php include("inc/footer.php"); ?>