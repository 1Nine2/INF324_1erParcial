
<?php include("inc/header.php"); ?>
	<div class="container">
<div class="row">
        <table class="table table-hover">
            <thead>
                <tr>
                    
                    <th scope="col">Promedio</th>
                    <th scope="col">Cod Departamento</th>
                  
                </tr>
            </thead>
            <tbody>
                <tr class="table-active">
                    
                <th scope="col">01</th>
                <th scope="col">50</th>
                </tr>
                <tr class="table-active">

                
                <th scope="col">02</th>
                <th scope="col">60</th>
                </tr>
            </tbody>
        </table>

    </div>